import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topmost-header',
  templateUrl: './topmost-header.component.html',
  styleUrls: ['./topmost-header.component.scss']
})
export class TopmostHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
