import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-verification',
  templateUrl: './sms-verification.component.html',
  styleUrls: ['./sms-verification.component.scss']
})
export class SMSVerification implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
