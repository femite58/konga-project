import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-price-range',
  templateUrl: './custom-price-range.component.html',
  styleUrls: ['./custom-price-range.component.scss']
})
export class CustomPriceRangeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
