import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spons-products',
  templateUrl: './spons-products.component.html',
  styleUrls: ['./spons-products.component.scss']
})
export class SponsProductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
