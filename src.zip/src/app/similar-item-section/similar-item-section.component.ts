import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-similar-item-section',
  templateUrl: './similar-item-section.component.html',
  styleUrls: ['./similar-item-section.component.scss']
})
export class SimilarItemSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
