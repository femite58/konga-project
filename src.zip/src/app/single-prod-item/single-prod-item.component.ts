import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-prod-item',
  templateUrl: './single-prod-item.component.html',
  styleUrls: ['./single-prod-item.component.scss']
})
export class SingleProdItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
