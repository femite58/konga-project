import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cat-list-page',
  templateUrl: './cat-list-page.component.html',
  styleUrls: ['./cat-list-page.component.scss']
})
export class CatListPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
